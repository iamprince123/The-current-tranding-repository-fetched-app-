package com.an.github.data;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}